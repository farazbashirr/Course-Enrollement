﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace CourseEnrolment.Models
{
    public class Student
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public decimal Id { get; set; }
        public string Name { get; set; }
        public string CNIC { get; set; }
        public string Email { get; set; }
        public decimal Password { get; set; }

        [DataType(DataType.Date)]
        public DateTime Date { get; set; } = DateTime.Now.Date;
    }
}