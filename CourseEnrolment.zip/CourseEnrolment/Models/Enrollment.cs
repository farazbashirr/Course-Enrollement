﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace CourseEnrolment.Models
{
    public class Enrollment
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]

        public decimal Id { get; set; }
        public decimal StudentId { get; set; }
        public decimal CourseId { get; set; }

        [DataType(DataType.Date)]
        public DateTime Date { get; set; } = DateTime.Now.Date;
    }
}