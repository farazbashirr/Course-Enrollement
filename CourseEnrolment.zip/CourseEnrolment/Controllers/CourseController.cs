﻿using CourseEnrolment.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CourseEnrolment.Controllers
{
    public class CourseController : Controller
    {
        private Models.ApplicationDbContext _context;

        public CourseController()
        {
            _context = new ApplicationDbContext();
        }
        protected override void Dispose(bool disposing)
        {
            _context.Dispose();

        }
        public ActionResult Index()
        {
            var courselist = _context.course.ToList();
            return View(courselist);

        }
        public ActionResult New()
        {
            return View();
        }
        public ActionResult Save(Course course)
        {
            if (course.Id == 0)
            {

                _context.course.Add(course);
            }
            else
            {
                var coursedb = _context.course.Single(c => c.Id == course.Id);
                coursedb.Title = course.Title;
                coursedb.Description = course.Description;
                coursedb.CreditHours = course.CreditHours;              
            }
            try
            {
                _context.SaveChanges();
            }
            catch (System.Data.Entity.Validation.DbEntityValidationException dbEx)
            {
                Exception raise = dbEx;
                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        string message = string.Format("{0}:{1}",
                            validationErrors.Entry.Entity.ToString(),
                            validationError.ErrorMessage);
                        // raise a new exception nesting
                        // the current instance as InnerException
                        raise = new InvalidOperationException(message, raise);
                    }
                }
                throw raise;
            }


            return RedirectToAction("New", "course");
        }
        public ActionResult Edit(int Id)
        {
            var coursedata = _context.course.SingleOrDefault(c => c.Id == Id);
            if (coursedata == null)
                return new HttpStatusCodeResult(System.Net.HttpStatusCode.BadRequest);

            return View("New", coursedata);
        }
        public ActionResult Delete(int Id)
        {
            var dept = _context.course.SingleOrDefault(c => c.Id == Id);
            _context.course.Remove(dept);
            _context.SaveChanges();
            return RedirectToAction("Index", "course");
        }
    }
}