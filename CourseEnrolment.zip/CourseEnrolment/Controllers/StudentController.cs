﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CourseEnrolment.Models;

namespace CourseEnrolment.Controllers
{
    public class StudentController : Controller
    {
        private Models.ApplicationDbContext _context;

        public StudentController()
        {
            _context = new ApplicationDbContext();
        }
        protected override void Dispose(bool disposing)
        {
            _context.Dispose();

        }
        public ActionResult Index()
        {
            var studentlist = _context.student.ToList();
            return View(studentlist);

        }
        public ActionResult New()
        {
            return View();
        }
        public ActionResult Save(Student student)
        {
            if (student.Id == 0)
            {

                _context.student.Add(student);
            }
            else
            {
                var studentdb = _context.student.Single(c => c.Id == student.Id);
                studentdb.Name = student.Name;
                studentdb.Email = student.Email;
                studentdb.CNIC = student.CNIC;
                studentdb.Password = student.Password;
                studentdb.Date = student.Date;
            }
            try
            {
                _context.SaveChanges();
            }
            catch (System.Data.Entity.Validation.DbEntityValidationException dbEx)
            {
                Exception raise = dbEx;
                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        string message = string.Format("{0}:{1}",
                            validationErrors.Entry.Entity.ToString(),
                            validationError.ErrorMessage);
                        // raise a new exception nesting
                        // the current instance as InnerException
                        raise = new InvalidOperationException(message, raise);
                    }
                }
                throw raise;
            }


            return RedirectToAction("New", "student");
        }
        public ActionResult Edit(int Id)
        {
            var studentdata = _context.student.SingleOrDefault(c => c.Id == Id);
            if (studentdata == null)
                return new HttpStatusCodeResult(System.Net.HttpStatusCode.BadRequest);

            return View("New", studentdata);
        }
        public ActionResult Delete(int Id)
        {
            var dept = _context.student.SingleOrDefault(c => c.Id == Id);
            _context.student.Remove(dept);
            _context.SaveChanges();
            return RedirectToAction("Index", "student");
        }

    }
}