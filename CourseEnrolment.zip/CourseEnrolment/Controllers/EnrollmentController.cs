﻿using CourseEnrolment.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CourseEnrolment.VM;

namespace CourseEnrolment.Controllers
{
    public class EnrollmentController : Controller
    {
        private Models.ApplicationDbContext _context;
        private Enrollment enrollment;

        public EnrollmentController()
        {
            _context = new ApplicationDbContext();
        }
        protected override void Dispose(bool disposing)
        {
            _context.Dispose();

        }
        public ActionResult Index()
        {

            var enrollmentlist = _context.enrollment.ToList();
            return View(enrollmentlist);

        }
        public ActionResult New()
        {
            var ViewModel = new EnrollmentVM()
            {
                studentlist = _context.student.ToList(),
                courselist = _context.course.ToList(),
                enrollment = enrollment
            };
            return View(ViewModel);
        }
        public ActionResult Save(Enrollment enrollment)
        {

            if (enrollment.Id == 0)
            {

                _context.enrollment.Add(enrollment);
            }
            else
            {
                var enrollmentdb = _context.enrollment.Single(c => c.Id == enrollment.Id);
                enrollmentdb.StudentId = enrollment.StudentId;
                enrollmentdb.CourseId = enrollment.CourseId;
                enrollmentdb.Date = enrollment.Date;
            }
            try
            {
                _context.SaveChanges();
            }
            catch (System.Data.Entity.Validation.DbEntityValidationException dbEx)
            {
                Exception raise = dbEx;
                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        string message = string.Format("{0}:{1}",
                            validationErrors.Entry.Entity.ToString(),
                            validationError.ErrorMessage);
                        // raise a new exception nesting
                        // the current instance as InnerException
                        raise = new InvalidOperationException(message, raise);
                    }
                }
                throw raise;
            }


            return RedirectToAction("New", "enrollment");
        }
        public ActionResult Edit(int Id)
        {
            var enrollmentdata = _context.enrollment.SingleOrDefault(c => c.Id == Id);
            if (enrollmentdata == null)
                return new HttpStatusCodeResult(System.Net.HttpStatusCode.BadRequest);

            return View("New", enrollmentdata);
        }
        public ActionResult Delete(int Id)
        {
            var dept = _context.enrollment.SingleOrDefault(c => c.Id == Id);
            _context.enrollment.Remove(dept);
            _context.SaveChanges();
            return RedirectToAction("Index", "enrollment");
        }
    }
}